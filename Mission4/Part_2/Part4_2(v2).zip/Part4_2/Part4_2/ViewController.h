//
//  ViewController.h
//  Part4_2
//
//  Created by 沈洋 on 16/3/11.
//  Copyright © 2016年 Sheny. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JKViewController.h"

@interface ViewController : UIViewController<AgentProtocol>


@end

