//
//  AgentProtocol.h
//  Part4_2
//
//  Created by 沈洋 on 16/3/11.
//  Copyright © 2016年 Sheny. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@protocol AgentProtocol <NSObject>
- (void)setColor:(UIColor *)color;
@end
