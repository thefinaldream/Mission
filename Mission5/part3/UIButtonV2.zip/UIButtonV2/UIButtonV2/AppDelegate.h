//
//  AppDelegate.h
//  UIButtonV2
//
//  Created by 沈洋 on 16/3/16.
//  Copyright © 2016年 Sheny. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

