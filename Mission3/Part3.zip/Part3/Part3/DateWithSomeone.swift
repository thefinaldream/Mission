//
//  DateWithSomeone.swift
//  Part3
//
//  Created by Sheny on 16/2/29.
//  Copyright © 2016 Sheny. All rights reserved.
//

import Foundation
/**
 *  <#Description#> 约会接口具体功能由类中实现
 */
protocol DateWithSomeone{
    func DateWith()
}